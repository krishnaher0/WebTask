package com.example.taskwebdev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskWebDevApplication {

    public static void main(String[] args) {
        SpringApplication.run(TaskWebDevApplication.class, args);
    }

}
